package com.cts.product.dao;

import java.util.List;


import com.cts.product.bean.Vendors;

public interface VendorDAO {

	public String insertVendor(Vendors vendors);
	public List<Vendors> getAllVendors();
}
