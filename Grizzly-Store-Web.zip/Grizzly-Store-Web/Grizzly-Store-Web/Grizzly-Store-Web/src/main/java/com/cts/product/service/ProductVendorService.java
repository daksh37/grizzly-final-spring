package com.cts.product.service;

import java.util.List;

import com.cts.product.bean.Product;
import com.cts.product.bean.ProductVendor;

public interface ProductVendorService {
	public List<ProductVendor> getAllProductVendor();
	public String insertProductVendor(ProductVendor productVendor);
	public List<ProductVendor> getDescProductVendor();
	public List<ProductVendor> getAscProductVendor();
}
