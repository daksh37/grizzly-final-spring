package com.cts.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.product.bean.ProductVendor;
import com.cts.product.dao.ProductVendorDAO;

@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class ProductVendorServiceImpl implements ProductVendorService {
	@Autowired
	private ProductVendorDAO productVendorDAO;

	@Override
	public List<ProductVendor> getAllProductVendor() {
		// TODO Auto-generated method stub
		return productVendorDAO.getAllProductVendor();
	}

	@Override
	public String insertProductVendor(ProductVendor productVendor) {
		// TODO Auto-generated method stub
		return productVendorDAO.insertProductVendor(productVendor);
	}

	@Override
	public List<ProductVendor> getDescProductVendor() {
		// TODO Auto-generated method stub
		return productVendorDAO.getDescProductVendor();
	}

	@Override
	public List<ProductVendor> getAscProductVendor() {
		// TODO Auto-generated method stub
		return productVendorDAO.getAscProductVendor();
	}
}
