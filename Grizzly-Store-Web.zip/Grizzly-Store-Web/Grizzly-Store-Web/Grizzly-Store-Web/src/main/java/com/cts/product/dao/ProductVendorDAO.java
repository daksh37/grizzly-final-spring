package com.cts.product.dao;

import java.util.List;


import com.cts.product.bean.ProductVendor;

public interface ProductVendorDAO {

	public List<ProductVendor> getAllProductVendor();
	public String insertProductVendor(ProductVendor productVendor);
	public List<ProductVendor> getDescProductVendor();
	public List<ProductVendor> getAscProductVendor();
}
