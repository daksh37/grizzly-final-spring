package com.cts.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.product.bean.Vendors;
import com.cts.product.dao.VendorDAO;



@Service
@Transactional(propagation = Propagation.SUPPORTS)
public class VendorServiceImpl implements VendorService {
	@Autowired
	private VendorDAO vendorDAO;

	@Override
	public String insertVendor(Vendors vendors) {
		// TODO Auto-generated method stub
		return vendorDAO.insertVendor(vendors);
	}

	@Override
	public List<Vendors> getAllVendors() {
		// TODO Auto-generated method stub
		return vendorDAO.getAllVendors();
	}
}
