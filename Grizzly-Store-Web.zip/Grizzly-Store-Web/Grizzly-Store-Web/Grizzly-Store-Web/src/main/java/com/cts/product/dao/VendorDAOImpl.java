package com.cts.product.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.product.bean.Product;
import com.cts.product.bean.Vendors;


@Repository("vendorDAO")
public class VendorDAOImpl implements VendorDAO{

	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	
	@Transactional
	public String insertVendor(Vendors vendors) {
		// TODO Auto-generated method stub
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		//transaction = session.getTransaction();
		//transaction.begin();
		
		session.save(vendors);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public List<Vendors> getAllVendors() {
		// TODO Auto-generated method stub
		Session session = null;
		System.out.println("1111111111");
	      try {
	    	  String query= "from Vendors";
	    		Query<Vendors> query2=null;
	    		System.out.println("22");
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<Vendors> vendors = query2.getResultList();
	    				if(vendors==null)
	    					return null;
	    				else
	    					return vendors;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
		return null;
	}

}
