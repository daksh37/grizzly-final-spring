package com.cts.product.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.product.bean.Product;
import com.cts.product.bean.ProductVendor;




@Repository("productVendorDAO")
public class ProductVendorDAOImpl implements ProductVendorDAO{
	
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	
	
	@Transactional
	public List<ProductVendor> getAllProductVendor() {
		// TODO Auto-generated method stub
		
		Session session = null;
		
	      try {
	    	  String query= "from ProductVendor";
	    		Query<ProductVendor> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<ProductVendor> products = query2.getResultList();
	    				if(products==null)
	    					return null;
	    				else
	    					return products;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
		return null;
	}


	@Transactional
	public String insertProductVendor(ProductVendor productVendor) {
		// TODO Auto-generated method stub
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		//transaction = session.getTransaction();
		//transaction.begin();
		
		session.save(productVendor);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		return null;
	}


	@Transactional
	public List<ProductVendor> getDescProductVendor() {
		// TODO Auto-generated method stub
		Session session = null;
		
	      try {
	    	  String query= "from ProductVendor order by productName DESC";
	    		Query<ProductVendor> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<ProductVendor> products = query2.getResultList();
	    				if(products==null)
	    					return null;
	    				else
	    					return products;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
		return null;
	}


	@Transactional
	public List<ProductVendor> getAscProductVendor() {
		// TODO Auto-generated method stub
		Session session = null;
		
	      try {
	    	  String query= "from ProductVendor order by productName";
	    		Query<ProductVendor> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<ProductVendor> products = query2.getResultList();
	    				if(products==null)
	    					return null;
	    				else
	    					return products;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
		return null;
	}


}
